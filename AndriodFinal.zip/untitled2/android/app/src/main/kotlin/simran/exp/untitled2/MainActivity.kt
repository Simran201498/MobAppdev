package simran.exp.untitled2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
