import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Zumo',
      theme: ThemeData(
        primarySwatch: Colors.pink,
        scaffoldBackgroundColor: Colors.black,
        textTheme: TextTheme(
          headline6: TextStyle(color: Colors.white),
        ),
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Zumo', style: TextStyle(color: Colors.pink),),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://cdn.discordapp.com/attachments/1018747722297249872/1197284512271438006/Pngtreesummer_cartoon_cute_frog_reading_6494562.jpg?ex=65bab518&is=65a84018&hm=30b17613af2c7ebe89412411529075837a9042c27cc74526a1c536b6da64963c&',
              width: 150.0,
              height: 150.0,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 24.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SecondPage()),
                );
              },
              child: Text('Click to Begin'),

            ),
          ],
        ),
      ),
    );
  }
}

class SecondPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Zumo',  style: TextStyle(color: Colors.pink),),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.network(
              'https://cdn.discordapp.com/attachments/1018747722297249872/1197284512271438006/Pngtreesummer_cartoon_cute_frog_reading_6494562.jpg?ex=65bab518&is=65a84018&hm=30b17613af2c7ebe89412411529075837a9042c27cc74526a1c536b6da64963c&',
              width: 150.0,
              height: 150.0,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 24.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DailyTodoListPage()),
                );
              },
              child: Text('Daily To-Do List'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MonthlyGoalsPage()),
                );
              },
              child: Text('Monthly Goals'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyJournalPage()),
                );
              },
              child: Text('My Journal'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PasswordsPage()),
                );
              },
              child: Text('Passwords'),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate back to the home screen
          Navigator.pop(context);
        },
        child: Text(
          'Back',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

class DailyTodoListPage extends StatefulWidget {
  @override
  _DailyTodoListPageState createState() => _DailyTodoListPageState();
}

class _DailyTodoListPageState extends State<DailyTodoListPage> {
  List<String> tasks = [];
  late SharedPreferences _prefs;

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    _prefs = await SharedPreferences.getInstance();
    setState(() {
      tasks = _prefs.getStringList('tasks') ?? [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daily To-Do List', style: TextStyle(color: Colors.pink),),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Text('${index + 1}.'),
                    title: Text(
                      tasks[index],
                      style: TextStyle(color: Colors.white),
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.add),
                      onPressed: () {
                        // Remove the task when the plus icon is clicked
                        setState(() {
                          tasks.removeAt(index);
                          _prefs.setStringList('tasks', tasks);
                        });
                      },
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Add a new task when the button is clicked
                _showAddTaskDialog(context);
              },
              child: Text('Add Task'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Navigate back to the previous screen
                Navigator.pop(context);
              },
              child: Text('Back'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showAddTaskDialog(BuildContext context) async {
    TextEditingController taskController = TextEditingController();

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Add Task'),
          content: TextField(
            controller: taskController,
            decoration: InputDecoration(
              labelText: 'Enter your task',
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              onPressed: () {
                // Add the task and close the dialog
                setState(() {
                  tasks.add(taskController.text);
                  _prefs.setStringList('tasks', tasks);
                });
                Navigator.of(context).pop();
              },
              child: Text('Add'),
            ),
          ],
        );
      },
    );
  }
}

class MonthlyGoalsPage extends StatefulWidget {
  @override
  _MonthlyGoalsPageState createState() => _MonthlyGoalsPageState();
}

class _MonthlyGoalsPageState extends State<MonthlyGoalsPage> {
  TextEditingController goalsController = TextEditingController();
  late SharedPreferences _prefs;

  @override
  void initState() {
    super.initState();
    _initStateAsync();
  }

  Future<void> _initStateAsync() async {
    _prefs = await SharedPreferences.getInstance();
    goalsController.text = _prefs.getString('monthlyGoals') ?? '';
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Monthly Goals', style: TextStyle(color: Colors.pink),),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: TextField(
                controller: goalsController,
                maxLines: null, // Allows multiple lines
                decoration: InputDecoration(
                  labelText: 'Enter your monthly goals',
                ),
                style: TextStyle(color: Colors.white),
                textInputAction: TextInputAction.newline, // Allow new lines
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Save the goals and navigate back to the previous screen
                _saveGoals();
              },
              child: Text('Save Goals'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Navigate back to the previous screen without saving
                Navigator.pop(context);
              },
              child: Text('Back'),
            ),
          ],
        ),
      ),
    );
  }

  void _saveGoals() {
    // Save the entered goals
    String enteredGoals = goalsController.text;
    _prefs.setString('monthlyGoals', enteredGoals);
    // Navigate back to the previous screen
    Navigator.pop(context);
  }
}

class MyJournalPage extends StatefulWidget {
  @override
  _MyJournalPageState createState() => _MyJournalPageState();
}

class _MyJournalPageState extends State<MyJournalPage> {
  TextEditingController journalEntryController = TextEditingController();
  TextEditingController dateController = TextEditingController();
  TextEditingController dayController = TextEditingController();
  late SharedPreferences _prefs;
  List<String> savedEntries = [];

  @override
  void initState() {
    super.initState();
    _initStateAsync();
  }

  Future<void> _initStateAsync() async {
    _prefs = await SharedPreferences.getInstance();
    savedEntries = _prefs.getStringList('journalEntries') ?? [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Journal',  style: TextStyle(color: Colors.pink),),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: dateController,
                    decoration: InputDecoration(
                      labelText: 'Date',
                      labelStyle: TextStyle(color: Colors.white),
                    ),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                SizedBox(width: 16.0),
                Expanded(
                  child: TextField(
                    controller: dayController,
                    decoration: InputDecoration(
                      labelText: 'Day',
                      labelStyle: TextStyle(color: Colors.white),
                    ),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16.0),
            Expanded(
              child: TextField(
                controller: journalEntryController,
                maxLines: null,
                decoration: InputDecoration(
                  labelText: 'Write your thoughts here',
                ),
                style: TextStyle(color: Colors.white),
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Save the journal entry and navigate to the list screen
                _saveJournalEntry();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => JournalListPage(savedEntries)),
                );
              },
              child: Text('Save Journal Entry'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Navigate to the list screen without saving
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => JournalListPage(savedEntries)),
                );
              },
              child: Text('View Journal Entries'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Navigate back to the previous screen without saving
                Navigator.pop(context);
              },
              child: Text('Back'),
            ),
          ],
        ),
      ),
    );
  }

  void _saveJournalEntry() {
    // Save the entered journal entry
    String enteredJournalEntry = journalEntryController.text;
    String enteredDate = dateController.text;
    String enteredDay = dayController.text;

    savedEntries.add('$enteredDate $enteredDay: $enteredJournalEntry');

    // Save the updated list of entries
    _prefs.setStringList('journalEntries', savedEntries);
  }
}

class JournalListPage extends StatelessWidget {
  final List<String> entries;

  JournalListPage(this.entries);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Journal Entries'),
      ),
      body: ListView.builder(
        itemCount: entries.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(
              entries[index],
              style: TextStyle(color: Colors.white), // Set text color to white
            ),
            onTap: () {
              // Navigate to the edit screen with the selected entry
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditJournalEntryPage(entries, index),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class EditJournalEntryPage extends StatefulWidget {
  final List<String> entries;
  final int index;

  EditJournalEntryPage(this.entries, this.index);

  @override
  _EditJournalEntryPageState createState() => _EditJournalEntryPageState();
}

class _EditJournalEntryPageState extends State<EditJournalEntryPage> {
  TextEditingController editedJournalEntryController = TextEditingController();

  @override
  void initState() {
    super.initState();
    editedJournalEntryController.text = widget.entries[widget.index];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Journal Entry'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: TextField(
                controller: editedJournalEntryController,
                maxLines: null,
                decoration: InputDecoration(
                  labelText: 'Edit your thoughts here',
                ),
                style: TextStyle(color: Colors.white),
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Save the edited journal entry and navigate back to the list screen
                widget.entries[widget.index] = editedJournalEntryController.text;
                Navigator.pop(context);
              },
              child: Text('Save Changes'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Navigate back to the list screen without saving changes
                Navigator.pop(context);
              },
              child: Text('Back'),
            ),
          ],
        ),
      ),
    );
  }
}

class PasswordsPage extends StatefulWidget {
  @override
  _PasswordsPageState createState() => _PasswordsPageState();
}

class _PasswordsPageState extends State<PasswordsPage> {
  List<String> sources = [];
  List<String> usernames = [];
  List<String> passwords = [];
  TextEditingController sourceController = TextEditingController();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  late SharedPreferences _prefs;

  @override
  void initState() {
    super.initState();
    _initStateAsync();
  }

  Future<void> _initStateAsync() async {
    _prefs = await SharedPreferences.getInstance();
    _loadPasswordDetails();
  }

  Future<void> _loadPasswordDetails() async {
    setState(() {
      sources = _prefs.getStringList('sources') ?? [];
      usernames = _prefs.getStringList('usernames') ?? [];
      passwords = _prefs.getStringList('passwords') ?? [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Passwords', style: TextStyle(color: Colors.pink),),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Source',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
                Expanded(
                  child: Text(
                    'Username',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
                Expanded(
                  child: Text(
                    'Password',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8.0),
            Expanded(
              child: ListView.builder(
                itemCount: sources.length,
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              sources[index],
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              usernames[index],
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              passwords[index],
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8.0),
                    ],
                  );
                },
              ),
            ),
            SizedBox(height: 16.0),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: sourceController,
                    decoration: InputDecoration(
                      labelText: 'Enter Source',
                    ),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: usernameController,
                    decoration: InputDecoration(
                      labelText: 'Enter Username',
                    ),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: passwordController,
                    decoration: InputDecoration(
                      labelText: 'Enter Password',
                    ),
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Save the password details
                _savePasswordDetails();
              },
              child: Text('Save'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Show saved passwords (for demonstration purposes)
                _loadPasswordDetails();
              },
              child: Text('Show saved passwords'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Delete saved passwords
                _deletePasswords();
              },
              child: Text('Delete saved passwords'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Navigate back to the previous screen without saving
                Navigator.pop(context);
              },
              child: Text('Back'),
            ),
          ],
        ),
      ),
    );
  }

  void _savePasswordDetails() {
    // Save the entered password details
    String enteredSource = sourceController.text;
    String enteredUsername = usernameController.text;
    String enteredPassword = passwordController.text;

    // Add the details to the lists
    setState(() {
      sources.add(enteredSource);
      usernames.add(enteredUsername);
      passwords.add(enteredPassword);
      _prefs.setStringList('sources', sources);
      _prefs.setStringList('usernames', usernames);
      _prefs.setStringList('passwords', passwords);
    });

    // Clear the text fields
    sourceController.clear();
    usernameController.clear();
    passwordController.clear();
  }

  void _deletePasswords() {
    // Delete saved passwords
    setState(() {
      sources = [];
      usernames = [];
      passwords = [];
      _prefs.remove('sources');
      _prefs.remove('usernames');
      _prefs.remove('passwords');
    });
  }
}
